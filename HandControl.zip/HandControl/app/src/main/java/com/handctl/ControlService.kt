package com.handctl
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.*
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.Executors

/** خدمة أمامية: بتشغّل الكاميرا الأمامية + MediaPipe وتبعت النتيجة للمحرّك وللمعاينة */
class ControlService : LifecycleService() {
    companion object {
        var running = false
        var lastLm: FloatArray? = null
        var listener: ((FloatArray?) -> Unit)? = null
        var engine: Engine? = null
        private var preview: Preview? = null
        private var surface: Preview.SurfaceProvider? = null
        fun setSurface(s: Preview.SurfaceProvider?) { surface = s; preview?.setSurfaceProvider(s) }
    }
    private var landmarker: HandLandmarker? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("hc", "التحكم بالإيماءات", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "hc").setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("التحكم بالإيماءات شغّال").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)

        val eng = Engine(this).also { engine = it }
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.LIVE_STREAM).setNumHands(1)
            .setResultListener { res, _ ->
                val hand = res.landmarks().firstOrNull()
                val arr = hand?.let { pts -> FloatArray(63).also { a -> pts.forEachIndexed { i, p -> a[i * 3] = p.x(); a[i * 3 + 1] = p.y(); a[i * 3 + 2] = p.z() } } }
                lastLm = arr
                main.post { listener?.invoke(arr); eng.onHand(arr) }
            }.setErrorListener { }.build()
        landmarker = HandLandmarker.createFromOptions(this, opts)

        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val prov = fut.get()
            val pv = Preview.Builder().build().also { preview = it; it.setSurfaceProvider(surface) }
            val an = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            an.setAnalyzer(exec) { img ->
                val bmp = Bitmap.createBitmap(img.width, img.height, Bitmap.Config.ARGB_8888)
                img.planes[0].buffer.rewind(); bmp.copyPixelsFromBuffer(img.planes[0].buffer)
                val po = ImageProcessingOptions.builder().setRotationDegrees(img.imageInfo.rotationDegrees).build()
                landmarker?.detectAsync(BitmapImageBuilder(bmp).build(), po, SystemClock.uptimeMillis())
                img.close()
            }
            prov.unbindAll()
            prov.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, an)
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        running = false; preview = null; engine = null
        ProcessCameraProvider.getInstance(this).get().unbindAll()
        landmarker?.close(); exec.shutdown()
        super.onDestroy()
    }
}
