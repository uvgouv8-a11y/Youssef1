package com.handctl
import android.content.Context
import org.json.*
import kotlin.math.*

object Store {
    class Custom(val name: String, val action: String, val vec: FloatArray)
    private fun p(c: Context) = c.getSharedPreferences("hc", 0)
    fun builtin(c: Context, key: String) = p(c).getBoolean("b_$key", true)
    fun setBuiltin(c: Context, key: String, v: Boolean) = p(c).edit().putBoolean("b_$key", v).apply()
    fun load(c: Context): MutableList<Custom> {
        val a = JSONArray(p(c).getString("custom", "[]")); val l = mutableListOf<Custom>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i); val v = o.getJSONArray("v")
            l.add(Custom(o.getString("n"), o.getString("a"), FloatArray(v.length()) { v.getDouble(it).toFloat() }))
        }
        return l
    }
    fun save(c: Context, l: List<Custom>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("a", it.action).put("v", JSONArray(it.vec.map { x -> x.toDouble() }))) }
        p(c).edit().putString("custom", a.toString()).apply()
    }
}

val ACTIONS = linkedMapOf(
    "CLICK" to "ضغطة (كليك)", "SCROLL_UP" to "تمرير لفوق", "SCROLL_DOWN" to "تمرير لتحت",
    "BACK" to "رجوع", "HOME" to "الرئيسية", "RECENTS" to "التطبيقات الأخيرة", "NOTIFICATIONS" to "الإشعارات")

class Engine(private val ctx: Context) {
    var customs = Store.load(ctx)
    fun reload() { customs = Store.load(ctx) }

    private val hist = mutableListOf<Triple<Long, Float, Float>>()
    private var cx = 0f; private var cy = 0f
    private var lastPointer = 0L; private var lastClick = 0L
    private var palmY = -1f; private var acc = 0f; private var lastScroll = 0L
    private var cand: String? = null; private var cnt = 0; private var lastCustom = 0L

    private fun d(l: FloatArray, a: Int, b: Int) = hypot(l[a * 3] - l[b * 3], l[a * 3 + 1] - l[b * 3 + 1])
    private fun ext(l: FloatArray, tip: Int, pip: Int) = d(l, tip, 0) > d(l, pip, 0) * 1.08f

    fun onHand(l: FloatArray?) {
        val a = GestureAccessibility.inst ?: return
        val now = System.currentTimeMillis()
        if (l == null) { palmY = -1f; acc = 0f; cand = null; cnt = 0; return }

        // 1) إيماءات مخصصة
        val n = norm(l); var best: Store.Custom? = null; var bd = THRESH
        for (c in customs) { val x = dist(n, c.vec); if (x < bd) { bd = x; best = c } }
        if (best != null) {
            if (cand == best.name) cnt++ else { cand = best.name; cnt = 1 }
            if (cnt >= 6 && now - lastCustom > 1200) { lastCustom = now; run(a, best.action) }
            return
        }
        cand = null; cnt = 0

        val idx = ext(l, 8, 6); val mid = ext(l, 12, 10); val rng = ext(l, 16, 14); val pnk = ext(l, 20, 18)

        // 2) تمرير: كف مفتوح يتحرك لفوق/لتحت
        if (idx && mid && rng && pnk) {
            if (Store.builtin(ctx, "scroll")) {
                val y = l[9 * 3 + 1]
                if (palmY >= 0) acc += y - palmY
                palmY = y
                if (abs(acc) > 0.10f && now - lastScroll > 500) {
                    a.swipe(up = acc < 0); lastScroll = now; acc = 0f
                }
            }
            return
        }
        palmY = -1f; acc = 0f

        // 3) مؤشر: السبابة لوحدها = حرّك، قفل السبابة = كليك
        if (!Store.builtin(ctx, "pointer")) return
        if (idx && !mid && !rng && !pnk) {
            val m = 0.15f
            val tx = (((1 - l[8 * 3]) - m) / (1 - 2 * m)).coerceIn(0f, 1f) * a.sw
            val ty = ((l[8 * 3 + 1] - m) / (1 - 2 * m)).coerceIn(0f, 1f) * a.sh
            cx += (tx - cx) * 0.35f; cy += (ty - cy) * 0.35f
            a.moveCursor(cx, cy)
            hist.add(Triple(now, cx, cy)); hist.removeAll { now - it.first > 1000 }
            lastPointer = now
        } else if (!idx && !mid && !rng && !pnk && now - lastPointer < 600 && now - lastClick > 800) {
            val p = hist.firstOrNull { it.first >= lastPointer - 300 } ?: Triple(0L, cx, cy)
            a.moveCursor(p.second, p.third); a.tap(p.second, p.third)
            lastClick = now; lastPointer = 0
        }
    }

    private fun run(a: GestureAccessibility, act: String) {
        when (act) {
            "CLICK" -> a.tap(cx, cy)
            "SCROLL_UP" -> a.swipe(true)
            "SCROLL_DOWN" -> a.swipe(false)
            "BACK" -> a.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            "HOME" -> a.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            "RECENTS" -> a.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            "NOTIFICATIONS" -> a.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        }
    }

    companion object {
        var THRESH = 0.35f  // قلّلها لو الإيماءات بتتفعّل بالغلط، زوّدها لو مش بتتعرّف
        fun norm(l: FloatArray): FloatArray {
            val s = hypot(l[0] - l[27], l[1] - l[28]).coerceAtLeast(1e-4f)
            return FloatArray(63) { (l[it] - l[it % 3]) / s }
        }
        fun dist(a: FloatArray, b: FloatArray): Float {
            var t = 0f
            for (i in 0 until 21) t += sqrt((a[i * 3] - b[i * 3]).pow(2) + (a[i * 3 + 1] - b[i * 3 + 1]).pow(2) + (a[i * 3 + 2] - b[i * 3 + 2]).pow(2))
            return t / 21
        }
    }
}
