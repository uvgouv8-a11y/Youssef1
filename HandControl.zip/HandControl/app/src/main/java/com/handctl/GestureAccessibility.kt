package com.handctl
import android.accessibilityservice.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent

/** ينفّذ اللمس والسحب والرجوع ويرسم مؤشر فوق الشاشة */
class GestureAccessibility : AccessibilityService() {
    companion object { var inst: GestureAccessibility? = null }
    private val h = Handler(Looper.getMainLooper())
    private var cursor: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    val sw get() = resources.displayMetrics.widthPixels.toFloat()
    val sh get() = resources.displayMetrics.heightPixels.toFloat()
    private val r = 28

    override fun onServiceConnected() {
        inst = this
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cursor = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xAAFF1744.toInt()); setStroke(4, Color.WHITE) }
        }
        lp = WindowManager.LayoutParams(r * 2, r * 2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(cursor, lp)
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        inst = null
        cursor?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    fun moveCursor(x: Float, y: Float) = h.post {
        cursor?.let { lp.x = (x - r).toInt(); lp.y = (y - r).toInt(); (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(it, lp) }
    }
    fun tap(x: Float, y: Float) = h.post {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipe(up: Boolean) = h.post {
        val p = Path().apply {
            moveTo(sw / 2, if (up) sh * 0.7f else sh * 0.3f); lineTo(sw / 2, if (up) sh * 0.3f else sh * 0.7f)
        }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    fun global(a: Int) = h.post { performGlobalAction(a) }
}
