package com.handctl
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var pv: PreviewView
    private lateinit var overlay: HandOverlayView
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL }
        val w = resources.displayMetrics.widthPixels
        val box = FrameLayout(this)
        pv = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        overlay = HandOverlayView(this)
        box.addView(pv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        box.addView(overlay, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(box, LinearLayout.LayoutParams(w, w * 4 / 3))
        status = TextView(this).apply { setPadding(24, 16, 24, 16); textSize = 15f }
        root.addView(status)
        toggle = btn(root, "") { if (ControlService.running) stopService(Intent(this, ControlService::class.java)).also { postRefresh() } else start() }
        btn(root, "1) تفعيل خدمة إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(root, "إدارة الإيماءات (تفعيل / إلغاء)") { manage() }
        btn(root, "إضافة إيماءة جديدة") { addGesture() }
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    private fun btn(p: LinearLayout, t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
        p.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(24, 8, 24, 8) })
    }

    override fun onResume() {
        super.onResume()
        ControlService.setSurface(pv.surfaceProvider)
        ControlService.listener = { overlay.update(it) }
        refresh()
    }
    override fun onPause() {
        ControlService.setSurface(null); ControlService.listener = null
        super.onPause()
    }
    private fun postRefresh() = Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
    private fun refresh() {
        toggle.text = if (ControlService.running) "إيقاف التحكم" else "2) تشغيل التحكم"
        status.text = "الكاميرا: ${if (ControlService.running) "شغّالة" else "واقفة"}   |   إمكانية الوصول: ${if (GestureAccessibility.inst != null) "مفعّلة" else "غير مفعّلة"}"
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1); return
        }
        ContextCompat.startForegroundService(this, Intent(this, ControlService::class.java)); postRefresh()
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        if (rc == 1 && g.firstOrNull() == PackageManager.PERMISSION_GRANTED) start()
    }

    private fun manage() {
        val customs = Store.load(this)
        val names = mutableListOf("المؤشر: السبابة تحرّك + قفلها كليك", "التمرير: كف مفتوح لفوق/لتحت")
        customs.forEach { names.add("${it.name}  →  ${ACTIONS[it.action]}") }
        val checked = BooleanArray(names.size) { true }
        checked[0] = Store.builtin(this, "pointer"); checked[1] = Store.builtin(this, "scroll")
        AlertDialog.Builder(this).setTitle("شيل العلامة من أي إيماءة لإلغائها")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("حفظ") { _, _ ->
                Store.setBuiltin(this, "pointer", checked[0]); Store.setBuiltin(this, "scroll", checked[1])
                Store.save(this, customs.filterIndexed { i, _ -> checked[i + 2] })
                ControlService.engine?.reload()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun addGesture() {
        if (!ControlService.running) { Toast.makeText(this, "شغّل التحكم الأول", Toast.LENGTH_SHORT).show(); return }
        val et = EditText(this).apply { hint = "اسم الإيماءة" }
        AlertDialog.Builder(this).setTitle("إيماءة جديدة").setView(et)
            .setPositiveButton("التالي") { _, _ ->
                val name = et.text.toString().ifBlank { "إيماءة" }
                val keys = ACTIONS.keys.toList()
                AlertDialog.Builder(this).setTitle("إيه اللي تعمله؟")
                    .setItems(ACTIONS.values.toTypedArray()) { _, i -> capture(name, keys[i]) }.show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun capture(name: String, action: String) {
        val h = Handler(Looper.getMainLooper())
        for (s in 3 downTo 1) h.postDelayed({ Toast.makeText(this, "ثبّت إيدك... $s", Toast.LENGTH_SHORT).show() }, (3 - s) * 1000L)
        h.postDelayed({
            val lm = ControlService.lastLm
            if (lm == null) { Toast.makeText(this, "مفيش إيد ظاهرة، جرّب تاني", Toast.LENGTH_LONG).show(); return@postDelayed }
            val l = Store.load(this); l.add(Store.Custom(name, action, Engine.norm(lm)))
            Store.save(this, l); ControlService.engine?.reload()
            Toast.makeText(this, "تمت إضافة \"$name\"", Toast.LENGTH_LONG).show()
        }, 3200)
    }
}
