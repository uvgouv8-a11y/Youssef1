package com.handctl
import android.content.Context
import android.graphics.*
import android.view.View

/** يرسم مفاصل اليد (21 نقطة) والخطوط الخضراء فوق معاينة الكاميرا */
class HandOverlayView(c: Context) : View(c) {
    private var lm: FloatArray? = null
    private val line = Paint().apply { color = 0xFF00FF00.toInt(); strokeWidth = 8f; isAntiAlias = true }
    private val dot = Paint().apply { color = 0xFF00FF00.toInt(); isAntiAlias = true }
    fun update(a: FloatArray?) { lm = a; invalidate() }
    override fun onDraw(cv: Canvas) {
        val l = lm ?: return
        fun x(i: Int) = (1 - l[i * 3]) * width   // مقلوبة لأن الكاميرا الأمامية معكوسة
        fun y(i: Int) = l[i * 3 + 1] * height
        CONN.forEach { (a, b) -> cv.drawLine(x(a), y(a), x(b), y(b), line) }
        for (i in 0..20) cv.drawCircle(x(i), y(i), 9f, dot)
    }
    companion object {
        val CONN = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
            9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17)
    }
}
